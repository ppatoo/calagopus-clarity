# Clarity Theme & UI Enhancement Layer

Original Calagopus extension acting as a comprehensive panel theme, layout customizer, and UI enhancement layer.

## Target Platform & Compatibility
- **Calagopus Panel Version**: `>=1.2.9`
- **Target Git Commit**: `f89411e9b51273d4a6be0c534927b799a7fd448f`
- **Rust Toolchain**: `1.99.0+` (Edition 2024)
- **Node.js**: `>=24`, **pnpm**: `>=11`

## Package Identity
- **Package Name**: `dev.antigravity.clarity`
- **Identifier**: `dev_antigravity_clarity`
- **License**: MIT
